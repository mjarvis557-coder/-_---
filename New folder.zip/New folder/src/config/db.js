import { DatabaseSync } from "node:sqlite";
import bcrypt from "bcryptjs";
import env from "./env.js";

const db = new DatabaseSync("storage/store.db");

export const initializeDatabase = () => {
  db.exec(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      description TEXT NOT NULL,
      price INTEGER NOT NULL,
      delivery_type TEXT NOT NULL,
      image_path TEXT,
      file_path TEXT,
      external_link TEXT,
      zip_password TEXT,
      is_active INTEGER DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_code TEXT UNIQUE NOT NULL,
      product_id INTEGER NOT NULL,
      email TEXT NOT NULL,
      amount INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      payment_provider TEXT NOT NULL,
      payment_method TEXT DEFAULT 'manual_dana',
      payment_reference TEXT,
      payment_url TEXT,
      proof_path TEXT,
      approved_at TEXT,
      download_token TEXT UNIQUE,
      download_expires_at TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(product_id) REFERENCES products(id)
    );
  `);

  const orderColumns = db.prepare("PRAGMA table_info(orders)").all();
  if (!orderColumns.some((column) => column.name === "payment_method")) {
    db.exec("ALTER TABLE orders ADD COLUMN payment_method TEXT DEFAULT 'manual_dana';");
  }
  if (!orderColumns.some((column) => column.name === "proof_path")) {
    db.exec("ALTER TABLE orders ADD COLUMN proof_path TEXT;");
  }
  if (!orderColumns.some((column) => column.name === "approved_at")) {
    db.exec("ALTER TABLE orders ADD COLUMN approved_at TEXT;");
  }

  const admin = db.prepare("SELECT id FROM admins WHERE email = ?").get(env.adminEmail);
  if (!admin) {
    const hash = bcrypt.hashSync(env.adminPassword, 10);
    db.prepare("INSERT INTO admins (email, password_hash) VALUES (?, ?)").run(env.adminEmail, hash);
  }

  const productsCount = db.prepare("SELECT COUNT(*) as count FROM products").get().count;
  if (!productsCount) {
    const seed = db.prepare(`
      INSERT INTO products (name, slug, description, price, delivery_type, external_link)
      VALUES (@name, @slug, @description, @price, @delivery_type, @external_link)
    `);

    [
      {
        name: "UI Kit Premium Neon",
        slug: "ui-kit-premium-neon",
        description: "Template dashboard premium dengan komponen siap pakai dan animasi halus.",
        price: 149000,
        delivery_type: "download",
        external_link: null
      },
      {
        name: "Bundle Landing Page SaaS",
        slug: "bundle-landing-page-saas",
        description: "Kumpulan landing page modern dengan estetika startup kelas premium.",
        price: 249000,
        delivery_type: "email",
        external_link: null
      },
      {
        name: "Membership Private Resources",
        slug: "membership-private-resources",
        description: "Akses resource eksternal eksklusif untuk creator, founder, dan marketer.",
        price: 99000,
        delivery_type: "external",
        external_link: "https://example.com/private-membership"
      }
    ].forEach((item) => seed.run(item));
  }
};

export default db;
