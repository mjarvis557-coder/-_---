import dotenv from "dotenv";

dotenv.config();

const env = {
  port: Number(process.env.PORT || 4000),
  baseUrl: process.env.BASE_URL || "http://localhost:4000",
  jwtSecret: process.env.JWT_SECRET || "change-me-now",
  adminEmail: process.env.ADMIN_EMAIL || "admin@digitalstore.local",
  adminPassword: process.env.ADMIN_PASSWORD || "supersecret123",
  smtp: {
    host: process.env.SMTP_HOST || "",
    port: Number(process.env.SMTP_PORT || 2525),
    user: process.env.SMTP_USER || "",
    pass: process.env.SMTP_PASS || "",
    from: process.env.MAIL_FROM || "Digital Store <no-reply@digitalstore.local>"
  },
  paymentProvider: process.env.PAYMENT_PROVIDER || "mock",
  manualDanaNumber: process.env.MANUAL_DANA_NUMBER || "085166589307",
  manualDanaName: process.env.MANUAL_DANA_NAME || "Pemilik Toko",
  midtrans: {
    serverKey: process.env.MIDTRANS_SERVER_KEY || "",
    clientKey: process.env.MIDTRANS_CLIENT_KEY || "",
    isProduction: process.env.MIDTRANS_IS_PRODUCTION === "true"
  },
  xendit: {
    secretKey: process.env.XENDIT_SECRET_KEY || "",
    webhookToken: process.env.XENDIT_WEBHOOK_TOKEN || ""
  }
};

export default env;
