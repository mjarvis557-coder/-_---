import { Router } from "express";
import { body, param, validationResult } from "express-validator";
import db from "../config/db.js";
import env from "../config/env.js";
import { createOrder, markOrderPaid } from "../services/orderService.js";
import { imageUpload } from "../middleware/uploadMiddleware.js";

const router = Router();

router.get("/products", (_req, res) => {
  const products = db.prepare(`
    SELECT id, name, slug, description, price, delivery_type, image_path
    FROM products
    WHERE is_active = 1
    ORDER BY created_at DESC
  `).all();

  res.json({ products });
});

router.get("/products/:slug", [param("slug").notEmpty()], (req, res) => {
  const product = db.prepare(`
    SELECT id, name, slug, description, price, delivery_type, image_path
    FROM products
    WHERE slug = ? AND is_active = 1
  `).get(req.params.slug);

  if (!product) {
    return res.status(404).json({ message: "Produk tidak ditemukan." });
  }

  return res.json({ product });
});

router.post(
  "/orders",
  [body("productId").isInt({ min: 1 }), body("email").isEmail()],
  async (req, res, next) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(422).json({ message: "Input order tidak valid.", errors: errors.array() });
      }

      const result = await createOrder(req.body);
      return res.status(201).json(result);
    } catch (error) {
      return next(error);
    }
  }
);

router.get("/orders/:orderCode", [param("orderCode").notEmpty()], (req, res) => {
  const order = db.prepare(`
    SELECT orders.*, products.name as product_name, products.delivery_type, products.zip_password
    FROM orders
    JOIN products ON products.id = orders.product_id
    WHERE orders.order_code = ?
  `).get(req.params.orderCode);

  if (!order) {
    return res.status(404).json({ message: "Order tidak ditemukan." });
  }

  return res.json({
    order,
    manualPayment: {
      danaNumber: env.manualDanaNumber,
      danaName: env.manualDanaName
    }
  });
});

router.post("/orders/:orderCode/proof", imageUpload.single("proof"), (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE order_code = ?").get(req.params.orderCode);
  if (!order) {
    return res.status(404).json({ message: "Order tidak ditemukan." });
  }

  if (!req.file?.path) {
    return res.status(422).json({ message: "Bukti transfer wajib diupload." });
  }

  db.prepare(`
    UPDATE orders
    SET status = 'waiting_confirmation', proof_path = ?, updated_at = CURRENT_TIMESTAMP
    WHERE order_code = ?
  `).run(req.file.path, req.params.orderCode);

  return res.json({ message: "Bukti transfer berhasil dikirim. Menunggu konfirmasi admin." });
});

router.post("/orders/:orderCode/mock-pay", async (req, res, next) => {
  try {
    const order = await markOrderPaid(req.params.orderCode, `manual-${Date.now()}`);
    return res.json({
      message: "Order ditandai paid.",
      order,
      downloadUrl: order.download_token ? `/api/download/${order.download_token}` : null
    });
  } catch (error) {
    return next(error);
  }
});

router.get("/stats/public", (_req, res) => {
  const totals = db.prepare(`
    SELECT
      COUNT(*) as totalOrders,
      SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) as revenue
    FROM orders
  `).get();

  res.json({ stats: totals });
});

export default router;
