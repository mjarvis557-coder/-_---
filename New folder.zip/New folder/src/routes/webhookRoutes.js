import { Router } from "express";
import env from "../config/env.js";
import { markOrderPaid } from "../services/orderService.js";

const router = Router();

router.post("/midtrans", async (req, res, next) => {
  try {
    const orderCode = req.body?.order_id;
    const transactionStatus = req.body?.transaction_status;

    if (["capture", "settlement"].includes(transactionStatus)) {
      await markOrderPaid(orderCode, req.body.transaction_id);
    }

    return res.json({ received: true });
  } catch (error) {
    return next(error);
  }
});

router.post("/xendit", async (req, res, next) => {
  try {
    const webhookToken = req.headers["x-callback-token"];
    if (env.xendit.webhookToken && webhookToken !== env.xendit.webhookToken) {
      return res.status(401).json({ message: "Webhook token tidak valid." });
    }

    if (req.body?.status === "PAID") {
      await markOrderPaid(req.body.external_id, req.body.id);
    }

    return res.json({ received: true });
  } catch (error) {
    return next(error);
  }
});

router.post("/mock/settle", async (req, res, next) => {
  try {
    const order = await markOrderPaid(req.body.orderCode, `mock-${Date.now()}`);
    return res.json({ message: "Mock webhook sukses.", order });
  } catch (error) {
    return next(error);
  }
});

export default router;
