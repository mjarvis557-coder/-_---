import { Router } from "express";
import { body, validationResult } from "express-validator";
import db from "../config/db.js";
import { requireAdminAuth } from "../middleware/authMiddleware.js";
import { productUploads } from "../middleware/uploadMiddleware.js";

const router = Router();

router.use(requireAdminAuth);

router.get("/stats", (_req, res) => {
  const stats = db.prepare(`
    SELECT
      (SELECT COUNT(*) FROM products) as totalProducts,
      (SELECT COUNT(*) FROM orders WHERE status = 'paid') as totalPaidOrders,
      (SELECT COALESCE(SUM(amount), 0) FROM orders WHERE status = 'paid') as totalSales
  `).get();

  const recentOrders = db.prepare(`
    SELECT orders.order_code, orders.email, orders.amount, orders.status, orders.created_at, orders.proof_path, products.name as product_name
    FROM orders
    JOIN products ON products.id = orders.product_id
    ORDER BY orders.created_at DESC
    LIMIT 8
  `).all();

  res.json({ stats, recentOrders });
});

router.get("/products", (_req, res) => {
  const products = db.prepare("SELECT * FROM products ORDER BY created_at DESC").all();
  res.json({ products });
});

router.post(
  "/products",
  productUploads,
  [
    body("name").notEmpty(),
    body("slug").notEmpty(),
    body("description").notEmpty(),
    body("price").isInt({ min: 0 }),
    body("deliveryType").isIn(["download", "email", "external"])
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ message: "Input produk tidak valid.", errors: errors.array() });
    }

    const imagePath = req.files?.image?.[0]?.path || null;
    const filePath = req.files?.file?.[0]?.path || null;
    const {
      name,
      slug,
      description,
      price,
      deliveryType,
      externalLink = "",
      zipPassword = "",
      isActive = "1"
    } = req.body;

    db.prepare(`
      INSERT INTO products (name, slug, description, price, delivery_type, image_path, file_path, external_link, zip_password, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      name,
      slug,
      description,
      Number(price),
      deliveryType,
      imagePath,
      filePath,
      externalLink || null,
      zipPassword || null,
      Number(isActive)
    );

    return res.status(201).json({ message: "Produk berhasil ditambahkan." });
  }
);

router.put(
  "/products/:id",
  productUploads,
  [
    body("name").notEmpty(),
    body("slug").notEmpty(),
    body("description").notEmpty(),
    body("price").isInt({ min: 0 }),
    body("deliveryType").isIn(["download", "email", "external"])
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ message: "Input produk tidak valid.", errors: errors.array() });
    }

    const current = db.prepare("SELECT * FROM products WHERE id = ?").get(req.params.id);
    if (!current) {
      return res.status(404).json({ message: "Produk tidak ditemukan." });
    }

    const {
      name,
      slug,
      description,
      price,
      deliveryType,
      externalLink = "",
      zipPassword = "",
      isActive = "1"
    } = req.body;

    db.prepare(`
      UPDATE products
      SET name = ?, slug = ?, description = ?, price = ?, delivery_type = ?, image_path = ?, file_path = ?, external_link = ?, zip_password = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      name,
      slug,
      description,
      Number(price),
      deliveryType,
      req.files?.image?.[0]?.path || current.image_path,
      req.files?.file?.[0]?.path || current.file_path,
      externalLink || null,
      zipPassword || null,
      Number(isActive),
      req.params.id
    );

    return res.json({ message: "Produk berhasil diperbarui." });
  }
);

router.delete("/products/:id", (req, res) => {
  const result = db.prepare("DELETE FROM products WHERE id = ?").run(req.params.id);
  if (!result.changes) {
    return res.status(404).json({ message: "Produk tidak ditemukan." });
  }

  return res.json({ message: "Produk berhasil dihapus." });
});

router.get("/orders", (_req, res) => {
  const orders = db.prepare(`
    SELECT orders.*, products.name as product_name
    FROM orders
    JOIN products ON products.id = orders.product_id
    ORDER BY orders.created_at DESC
  `).all();

  res.json({ orders });
});

router.post("/orders/:orderCode/approve", async (req, res, next) => {
  try {
    const order = db.prepare("SELECT * FROM orders WHERE order_code = ?").get(req.params.orderCode);
    if (!order) {
      return res.status(404).json({ message: "Order tidak ditemukan." });
    }

    if (!order.proof_path && order.status !== "paid") {
      return res.status(422).json({ message: "Bukti transfer belum tersedia." });
    }

    const { markOrderPaid } = await import("../services/orderService.js");
    const paidOrder = await markOrderPaid(req.params.orderCode, `manual-approve-${Date.now()}`);
    return res.json({ message: "Order berhasil di-approve.", order: paidOrder });
  } catch (error) {
    return next(error);
  }
});

export default router;
