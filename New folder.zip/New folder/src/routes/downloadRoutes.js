import { Router } from "express";
import path from "path";
import { getOrderDownload } from "../services/downloadService.js";

const router = Router();

router.get("/:token", (req, res) => {
  const order = getOrderDownload(req.params.token);

  if (!order || order.status !== "paid") {
    return res.status(403).json({ message: "Akses download tidak valid." });
  }

  if (order.download_expires_at && new Date(order.download_expires_at) < new Date()) {
    return res.status(410).json({ message: "Link download sudah kedaluwarsa." });
  }

  if (order.delivery_type === "external") {
    return res.redirect(order.external_link);
  }

  if (!order.file_path) {
    return res.status(404).json({ message: "File produk belum tersedia." });
  }

  return res.download(path.resolve(order.file_path));
});

export default router;
