import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { body, validationResult } from "express-validator";
import db from "../config/db.js";
import env from "../config/env.js";

const router = Router();

router.post(
  "/login",
  [body("email").isEmail(), body("password").isLength({ min: 6 })],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ message: "Input login tidak valid.", errors: errors.array() });
    }

    const { email, password } = req.body;
    const admin = db.prepare("SELECT * FROM admins WHERE email = ?").get(email);
    if (!admin || !bcrypt.compareSync(password, admin.password_hash)) {
      return res.status(401).json({ message: "Email atau password salah." });
    }

    const token = jwt.sign({ id: admin.id, email: admin.email }, env.jwtSecret, { expiresIn: "12h" });
    return res.json({
      token,
      admin: {
        id: admin.id,
        email: admin.email
      }
    });
  }
);

export default router;
