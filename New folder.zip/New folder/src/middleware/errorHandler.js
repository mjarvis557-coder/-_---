export const notFoundHandler = (_req, res) => {
  res.status(404).json({ message: "Route tidak ditemukan." });
};

export const errorHandler = (error, _req, res, _next) => {
  console.error(error);
  const status = error.status || 500;
  res.status(status).json({
    message: error.message || "Terjadi kesalahan pada server.",
    details: error.details || null
  });
};
