import multer from "multer";
import path from "path";
import { randomUUID } from "crypto";

const createStorage = (destination) =>
  multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, destination),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname);
      cb(null, `${Date.now()}-${randomUUID()}${ext}`);
    }
  });

export const imageUpload = multer({
  storage: createStorage("storage/images"),
  limits: { fileSize: 5 * 1024 * 1024 }
});

export const productFileUpload = multer({
  storage: createStorage("storage/products"),
  limits: { fileSize: 100 * 1024 * 1024 }
});

export const productUploads = multer({
  storage: multer.diskStorage({
    destination: (_req, file, cb) => {
      const target = file.fieldname === "image" ? "storage/images" : "storage/products";
      cb(null, target);
    },
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname);
      cb(null, `${Date.now()}-${randomUUID()}${ext}`);
    }
  }),
  limits: { fileSize: 100 * 1024 * 1024 }
}).fields([
  { name: "image", maxCount: 1 },
  { name: "file", maxCount: 1 }
]);
