import { initializeDatabase } from "../config/db.js";

initializeDatabase();
console.log("Admin dan database telah diinisialisasi.");
