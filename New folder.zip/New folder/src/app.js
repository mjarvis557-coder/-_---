import express from "express";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";
import publicRoutes from "./routes/publicRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import adminRoutes from "./routes/adminRoutes.js";
import webhookRoutes from "./routes/webhookRoutes.js";
import downloadRoutes from "./routes/downloadRoutes.js";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir = path.join(__dirname, "..", "public");
const storageDir = path.join(__dirname, "..", "storage");

const app = express();

app.use(cors());
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use("/storage/images", express.static(path.join(storageDir, "images")));
app.use("/public/uploads", express.static(path.join(publicDir, "uploads")));
app.use(express.static(publicDir));

app.get("/health", (_req, res) => {
  res.json({ ok: true });
});

app.use("/api", publicRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/webhooks", webhookRoutes);
app.use("/api/download", downloadRoutes);

app.get("/admin", (_req, res) => {
  res.sendFile(path.join(publicDir, "admin", "login.html"));
});

app.get("/admin/dashboard", (_req, res) => {
  res.sendFile(path.join(publicDir, "admin", "dashboard.html"));
});

app.get("/ads", (_req, res) => {
  res.sendFile(path.join(publicDir, "ads.html"));
});

app.get("/checkout", (_req, res) => {
  res.sendFile(path.join(publicDir, "checkout.html"));
});

app.use(notFoundHandler);
app.use(errorHandler);

export default app;
