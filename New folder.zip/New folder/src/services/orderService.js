import { v4 as uuidv4 } from "uuid";
import db from "../config/db.js";
import { createPayment } from "./paymentService.js";
import { createDownloadPayload } from "./downloadService.js";
import { sendPurchaseEmail } from "./emailService.js";

export const createOrder = async ({ productId, email }) => {
  const product = db.prepare("SELECT * FROM products WHERE id = ? AND is_active = 1").get(productId);

  if (!product) {
    const error = new Error("Produk tidak ditemukan.");
    error.status = 404;
    throw error;
  }

  const orderCode = `ORD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
  db.prepare(`
    INSERT INTO orders (order_code, product_id, email, amount, payment_provider, payment_method, status)
    VALUES (?, ?, ?, ?, ?, ?, 'pending')
  `).run(orderCode, product.id, email, product.price, "manual", "manual_dana");

  const payment = await createPayment({
    orderCode,
    amount: product.price,
    customerEmail: email,
    productName: product.name
  });

  db.prepare(`
    UPDATE orders
    SET payment_provider = ?, payment_method = ?, payment_reference = ?, payment_url = ?, updated_at = CURRENT_TIMESTAMP
    WHERE order_code = ?
  `).run(payment.provider, payment.payload?.method || "manual_dana", payment.reference, payment.paymentUrl, orderCode);

  const order = db.prepare(`
    SELECT orders.*, products.name as product_name, products.delivery_type, products.description
    FROM orders
    JOIN products ON products.id = orders.product_id
    WHERE orders.order_code = ?
  `).get(orderCode);

  return { order, payment };
};

export const markOrderPaid = async (orderCode, reference = uuidv4()) => {
  const order = db.prepare(`
    SELECT orders.*, products.name as product_name, products.delivery_type, products.file_path, products.external_link, products.zip_password
    FROM orders
    JOIN products ON products.id = orders.product_id
    WHERE orders.order_code = ?
  `).get(orderCode);

  if (!order) {
    const error = new Error("Order tidak ditemukan.");
    error.status = 404;
    throw error;
  }

  if (order.status === "paid") {
    return order;
  }

  db.prepare(`
    UPDATE orders
    SET status = 'paid', payment_reference = ?, approved_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
    WHERE order_code = ?
  `).run(reference, orderCode);

  const download = createDownloadPayload(order.id);
  await sendPurchaseEmail({
    to: order.email,
    productName: order.product_name,
    downloadUrl: download.downloadUrl,
    zipPassword: order.zip_password,
    deliveryType: order.delivery_type,
    externalLink: order.external_link
  });

  return db.prepare(`
    SELECT orders.*, products.name as product_name, products.delivery_type, products.file_path, products.external_link, products.zip_password
    FROM orders
    JOIN products ON products.id = orders.product_id
    WHERE orders.order_code = ?
  `).get(orderCode);
};
