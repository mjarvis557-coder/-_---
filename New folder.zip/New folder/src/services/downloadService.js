import { randomUUID } from "crypto";
import db from "../config/db.js";
import env from "../config/env.js";

export const createDownloadPayload = (orderId) => {
  const token = randomUUID();
  const expiresAt = new Date(Date.now() + 1000 * 60 * 60 * 24 * 3).toISOString();

  db.prepare(`
    UPDATE orders
    SET download_token = ?, download_expires_at = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(token, expiresAt, orderId);

  return {
    token,
    expiresAt,
    downloadUrl: `${env.baseUrl}/api/download/${token}`
  };
};

export const getOrderDownload = (token) =>
  db.prepare(`
    SELECT orders.*, products.name as product_name, products.delivery_type, products.file_path, products.external_link, products.zip_password
    FROM orders
    JOIN products ON products.id = orders.product_id
    WHERE orders.download_token = ?
  `).get(token);
