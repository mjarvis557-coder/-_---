import midtransClient from "midtrans-client";
import env from "../config/env.js";

const sanitizeAmount = (amount) => Number(amount || 0);

export const createPayment = async ({ orderCode, amount, customerEmail, productName }) => {
  const provider = env.paymentProvider.toLowerCase();

  if (provider === "manual") {
    return {
      provider: "manual",
      paymentUrl: `${env.baseUrl}/checkout?order=${orderCode}`,
      reference: `manual-${orderCode}`,
      payload: {
        method: "manual_dana",
        danaNumber: env.manualDanaNumber,
        danaName: env.manualDanaName,
        amount: sanitizeAmount(amount),
        customerEmail,
        productName
      }
    };
  }

  if (provider === "midtrans" && env.midtrans.serverKey) {
    const snap = new midtransClient.Snap({
      isProduction: env.midtrans.isProduction,
      serverKey: env.midtrans.serverKey,
      clientKey: env.midtrans.clientKey
    });

    const transaction = await snap.createTransaction({
      transaction_details: {
        order_id: orderCode,
        gross_amount: sanitizeAmount(amount)
      },
      customer_details: {
        email: customerEmail
      },
      item_details: [
        {
          id: orderCode,
          price: sanitizeAmount(amount),
          quantity: 1,
          name: productName
        }
      ],
      enabled_payments: ["gopay", "qris", "shopeepay", "dana"]
    });

    return {
      provider: "midtrans",
      paymentUrl: transaction.redirect_url,
      reference: transaction.token,
      payload: transaction
    };
  }

  if (provider === "xendit" && env.xendit.secretKey) {
    const response = await fetch("https://api.xendit.co/v2/invoices", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${Buffer.from(`${env.xendit.secretKey}:`).toString("base64")}`
      },
      body: JSON.stringify({
        amount: sanitizeAmount(amount),
        invoice_duration: 1800,
        external_id: orderCode,
        description: `Pembelian ${productName}`,
        payer_email: customerEmail,
        currency: "IDR",
        success_redirect_url: `${env.baseUrl}/checkout?success=1&order=${orderCode}`,
        failure_redirect_url: `${env.baseUrl}/checkout?failed=1&order=${orderCode}`,
        payment_methods: ["DANA", "QRIS", "BCA", "BSI", "BNI", "BRI"]
      })
    });

    const invoice = await response.json();
    if (!response.ok) {
      throw new Error(invoice.message || "Gagal membuat invoice Xendit.");
    }

    return {
      provider: "xendit",
      paymentUrl: invoice.invoice_url,
      reference: invoice.id,
      payload: invoice
    };
  }

  return {
    provider: "manual",
    paymentUrl: `${env.baseUrl}/checkout?order=${orderCode}`,
    reference: `manual-${orderCode}`,
    payload: {
      method: "manual_dana",
      danaNumber: env.manualDanaNumber,
      danaName: env.manualDanaName,
      amount: sanitizeAmount(amount),
      customerEmail,
      productName
    }
  };
};
