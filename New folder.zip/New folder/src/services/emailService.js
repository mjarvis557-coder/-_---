import nodemailer from "nodemailer";
import env from "../config/env.js";

const transporter = env.smtp.host
  ? nodemailer.createTransport({
      host: env.smtp.host,
      port: env.smtp.port,
      secure: env.smtp.port === 465,
      auth: {
        user: env.smtp.user,
        pass: env.smtp.pass
      }
    })
  : null;

export const sendPurchaseEmail = async ({ to, productName, downloadUrl, zipPassword, deliveryType, externalLink }) => {
  if (!transporter) {
    console.log("SMTP belum dikonfigurasi. Email dilewati.");
    return { skipped: true };
  }

  const detailLine =
    deliveryType === "external"
      ? `<p>Akses produk Anda: <a href="${externalLink}">${externalLink}</a></p>`
      : `<p>Link download aman: <a href="${downloadUrl}">${downloadUrl}</a></p>`;

  const passwordLine = zipPassword ? `<p>Password ZIP: <strong>${zipPassword}</strong></p>` : "";

  await transporter.sendMail({
    from: env.smtp.from,
    to,
    subject: `Pembelian berhasil - ${productName}`,
    html: `
      <div style="font-family: Arial, sans-serif; background:#0b1020; color:#f3f7ff; padding:24px">
        <h2>Pembayaran berhasil</h2>
        <p>Terima kasih sudah membeli <strong>${productName}</strong>.</p>
        ${detailLine}
        ${passwordLine}
        <p>Link ini bersifat unik dan aman.</p>
      </div>
    `
  });

  return { skipped: false };
};
