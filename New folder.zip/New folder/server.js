import app from "./src/app.js";
import env from "./src/config/env.js";
import { initializeDatabase } from "./src/config/db.js";

initializeDatabase();

app.listen(env.port, () => {
  console.log(`Digital store is running on ${env.baseUrl}`);
});
