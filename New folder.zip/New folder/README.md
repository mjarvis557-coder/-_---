# Premium Digital Store

Website toko digital otomatis dengan UI dark premium, animasi halus, admin panel modern, checkout, pembayaran manual DANA, email delivery, dan protected download.

## Stack

- Frontend: HTML, CSS, Vanilla JS
- Backend: Node.js + Express
- Database: SQLite via `node:sqlite`
- Upload: Multer
- Email: Nodemailer
- Payment: Manual DANA, plus adapter Midtrans / Xendit bila nanti ingin diaktifkan lagi

## Fitur Utama

- Home dengan hero slider, parallax ringan, skeleton loader, product grid, dan tombol glow
- Halaman ads fullscreen dengan countdown dan auto redirect ke checkout
- Halaman checkout modern dengan instruksi transfer manual dan upload bukti
- Admin login JWT
- Dashboard admin dengan statistik, CRUD produk, upload gambar dan file
- Tipe delivery produk: `download`, `email`, `external`
- Approval pembayaran manual dari admin panel
- Link download unik yang hanya aktif setelah pembayaran sukses

## Jalankan

1. Salin `.env.example` menjadi `.env`
2. Sesuaikan konfigurasi SMTP dan payment provider
3. Install dependency:

```bash
npm install
```

4. Jalankan aplikasi:

```bash
npm run dev
```

5. Buka:

- Store: `http://localhost:4000`
- Admin: `http://localhost:4000/admin`

## Default Admin

- Email: `admin@digitalstore.local`
- Password: `supersecret123`

## Endpoint Penting

- `GET /api/products`
- `POST /api/orders`
- `POST /api/orders/:orderCode/proof`
- `POST /api/webhooks/midtrans`
- `POST /api/webhooks/xendit`
- `POST /api/admin/orders/:orderCode/approve`
- `POST /api/auth/login`
- `GET /api/admin/stats`
- `POST /api/admin/products`
- `GET /api/download/:token`

## Catatan Payment

- Set `PAYMENT_PROVIDER=manual` untuk flow transfer manual ke DANA
- Set `PAYMENT_PROVIDER=midtrans` lalu isi key Midtrans untuk produksi/sandbox
- Set `PAYMENT_PROVIDER=xendit` lalu isi secret key + callback token untuk Xendit

## Struktur Folder

```text
public/
  admin/
  css/
  js/
src/
  config/
  middleware/
  routes/
  services/
  utils/
storage/
  images/
  products/
server.js
```
