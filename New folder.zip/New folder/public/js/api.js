const jsonHeaders = {
  "Content-Type": "application/json"
};

export const api = {
  async get(url, token) {
    const response = await fetch(url, {
      headers: token ? { Authorization: `Bearer ${token}` } : undefined
    });
    return handleResponse(response);
  },
  async post(url, data, token) {
    const response = await fetch(url, {
      method: "POST",
      headers: token ? { ...jsonHeaders, Authorization: `Bearer ${token}` } : jsonHeaders,
      body: JSON.stringify(data)
    });
    return handleResponse(response);
  },
  async upload(url, formData, method = "POST", token) {
    const response = await fetch(url, {
      method,
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
      body: formData
    });
    return handleResponse(response);
  },
  async delete(url, token) {
    const response = await fetch(url, {
      method: "DELETE",
      headers: token ? { Authorization: `Bearer ${token}` } : undefined
    });
    return handleResponse(response);
  }
};

async function handleResponse(response) {
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.message || "Request gagal.");
  }
  return data;
}
