export const rupiah = (value) =>
  new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0
  }).format(Number(value || 0));

export const showToast = (message, type = "info") => {
  const container = document.getElementById("toast-container");
  if (!container) return;

  const toast = document.createElement("div");
  toast.className = "toast";
  toast.innerHTML = `<strong>${type === "success" ? "Sukses" : "Info"}</strong><div>${message}</div>`;
  container.appendChild(toast);

  setTimeout(() => toast.remove(), 3200);
};

export const setButtonLoading = (button, loading) => {
  if (!button) return;
  button.classList.toggle("loading", loading);
  button.disabled = loading;
};

export const revealOnScroll = () => {
  const targets = document.querySelectorAll(".reveal");
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("visible");
        }
      });
    },
    { threshold: 0.14 }
  );

  targets.forEach((target) => observer.observe(target));
};

export const hideGlobalLoader = () => {
  document.getElementById("app-loader")?.classList.remove("active");
};
