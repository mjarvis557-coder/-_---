import { api } from "./api.js";
import { hideGlobalLoader, revealOnScroll, rupiah, showToast } from "./ui.js";

const grid = document.getElementById("products-grid");
const sliderTrack = document.getElementById("promo-slider");
const sliderDots = document.getElementById("slider-dots");

renderSkeletons();
revealOnScroll();
initSlider();
initParallax();
loadProducts();

async function loadProducts() {
  try {
    const { products } = await api.get("/api/products");
    grid.innerHTML = products
      .map(
        (product) => `
          <article class="product-card reveal">
            <div class="product-media">
              <span class="product-badge">${product.delivery_type}</span>
              <img src="${resolveImage(product.image_path)}" alt="${product.name}" />
            </div>
            <div class="product-meta">
              <h3>${product.name}</h3>
              <span class="price">${rupiah(product.price)}</span>
              <p>${product.description}</p>
              <button class="btn btn-primary glow buy-button" data-product-id="${product.id}" data-product-name="${product.name}">Beli</button>
            </div>
          </article>
        `
      )
      .join("");

    revealOnScroll();

    document.querySelectorAll(".buy-button").forEach((button) => {
      button.addEventListener("click", () => {
        const params = new URLSearchParams({
          productId: button.dataset.productId,
          name: button.dataset.productName
        });
        window.location.href = `/ads?${params.toString()}`;
      });
    });
  } catch (error) {
    showToast(error.message);
    grid.innerHTML = "<p class='muted'>Produk gagal dimuat.</p>";
  } finally {
    hideGlobalLoader();
  }
}

function resolveImage(imagePath) {
  if (!imagePath) {
    return "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80";
  }

  return `/${imagePath.replaceAll("\\", "/")}`;
}

function renderSkeletons() {
  grid.innerHTML = Array.from({ length: 6 })
    .map(() => `<div class="skeleton-card"></div>`)
    .join("");
}

function initSlider() {
  if (!sliderTrack || !sliderDots) return;
  const slides = Array.from(sliderTrack.children);
  let current = 0;

  slides.forEach((_, index) => {
    const dot = document.createElement("button");
    if (index === 0) dot.classList.add("active");
    dot.addEventListener("click", () => setSlide(index));
    sliderDots.appendChild(dot);
  });

  const setSlide = (index) => {
    current = index;
    sliderTrack.style.transform = `translateX(-${current * 100}%)`;
    sliderDots.querySelectorAll("button").forEach((dot, dotIndex) => {
      dot.classList.toggle("active", dotIndex === current);
    });
  };

  setInterval(() => setSlide((current + 1) % slides.length), 4600);
}

function initParallax() {
  const visual = document.querySelector(".parallax-layer");
  if (!visual) return;

  window.addEventListener("mousemove", (event) => {
    const x = (event.clientX / window.innerWidth - 0.5) * 14;
    const y = (event.clientY / window.innerHeight - 0.5) * 14;
    visual.style.transform = `translate3d(${x}px, ${y}px, 0)`;
  });
}
