import { api } from "./api.js";
import { setButtonLoading, showToast, revealOnScroll } from "./ui.js";

const form = document.getElementById("login-form");
revealOnScroll();

form?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = form.querySelector("button");
  const formData = new FormData(form);

  try {
    setButtonLoading(button, true);
    const result = await api.post("/api/auth/login", {
      email: formData.get("email"),
      password: formData.get("password")
    });

    localStorage.setItem("adminToken", result.token);
    showToast("Login berhasil.", "success");
    setTimeout(() => {
      window.location.href = "/admin/dashboard";
    }, 700);
  } catch (error) {
    showToast(error.message);
  } finally {
    setButtonLoading(button, false);
  }
});
