import { api } from "./api.js";
import { rupiah, setButtonLoading, showToast, revealOnScroll } from "./ui.js";

const params = new URLSearchParams(window.location.search);
const productId = params.get("productId");
const orderCode = params.get("order");
const paymentSuccess = params.get("success");
const paymentFailed = params.get("failed");

const checkoutProduct = document.getElementById("checkout-product");
const form = document.getElementById("checkout-form");
const proofForm = document.getElementById("proof-form");
const manualPanel = document.getElementById("manual-payment-panel");

revealOnScroll();

if (productId) {
  loadProduct(productId);
}

if (orderCode && !productId) {
  loadOrder(orderCode);
}

if (paymentSuccess) {
  showToast("Pembayaran berhasil diverifikasi.", "success");
}

if (paymentFailed) {
  showToast("Pembayaran belum berhasil. Silakan coba lagi.");
}

form?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = form.querySelector("button");
  const email = new FormData(form).get("email");

  try {
    setButtonLoading(button, true);
    const result = await api.post("/api/orders", {
      productId: Number(productId),
      email
    });

    showToast("Order dibuat. Menampilkan instruksi transfer DANA...", "success");
    setTimeout(() => {
      window.location.href = result.payment.paymentUrl;
    }, 900);
  } catch (error) {
    showToast(error.message);
  } finally {
    setButtonLoading(button, false);
  }
});

proofForm?.addEventListener("submit", async (event) => {
  event.preventDefault();
  const button = proofForm.querySelector("button");

  try {
    setButtonLoading(button, true);
    const formData = new FormData(proofForm);
    await api.upload(`/api/orders/${orderCode}/proof`, formData);
    showToast("Bukti transfer dikirim. Menunggu konfirmasi admin.", "success");
    await loadOrder(orderCode);
  } catch (error) {
    showToast(error.message);
  } finally {
    setButtonLoading(button, false);
  }
});

async function loadProduct(id) {
  try {
    const products = await api.get("/api/products");
    const product = products.products.find((item) => item.id === Number(id));
    if (!product) throw new Error("Produk tidak ditemukan.");

    checkoutProduct.classList.remove("skeleton-block");
    checkoutProduct.innerHTML = `
      <span class="eyebrow">${product.delivery_type}</span>
      <h2>${product.name}</h2>
      <p>${product.description}</p>
      <strong class="price">${rupiah(product.price)}</strong>
    `;
  } catch (error) {
    showToast(error.message);
  }
}

async function loadOrder(currentOrderCode) {
  try {
    const { order, manualPayment } = await api.get(`/api/orders/${currentOrderCode}`);
    checkoutProduct.classList.remove("skeleton-block");
    checkoutProduct.innerHTML = `
      <span class="eyebrow">${order.status}</span>
      <h2>${order.product_name}</h2>
      <p>Email: ${order.email}</p>
      <strong class="price">${rupiah(order.amount)}</strong>
    `;

    if (order.status === "paid" && order.download_token) {
      checkoutProduct.innerHTML += `<a class="btn btn-secondary" href="/api/download/${order.download_token}">Download Produk</a>`;
    }

    form.style.display = "none";
    manualPanel.style.display = "grid";
    manualPanel.innerHTML = `
      <span class="eyebrow">Transfer Manual</span>
      <h3>DANA ${manualPayment.danaName}</h3>
      <p>Transfer tepat sebesar <strong>${rupiah(order.amount)}</strong> ke nomor berikut:</p>
      <strong class="price">${manualPayment.danaNumber}</strong>
      <p class="muted">Setelah transfer, upload bukti pembayaran agar admin bisa approve pesanan Anda.</p>
    `;

    proofForm.style.display = order.status === "pending" || order.status === "waiting_confirmation" ? "grid" : "none";
  } catch (error) {
    showToast(error.message);
  }
}
