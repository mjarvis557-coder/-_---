const params = new URLSearchParams(window.location.search);
const countdownEl = document.getElementById("countdown");
const progressBar = document.getElementById("progress-bar");
const copy = document.getElementById("ads-product-copy");
const productName = params.get("name") || "produk pilihan Anda";
const productId = params.get("productId");

copy.textContent = `Menampilkan transisi iklan premium sebelum Anda melanjutkan pembelian ${productName}.`;

let seconds = 5;
countdownEl.textContent = seconds;

const interval = setInterval(() => {
  seconds -= 1;
  countdownEl.textContent = Math.max(seconds, 0);
  progressBar.style.width = `${((5 - seconds) / 5) * 100}%`;

  if (seconds <= 0) {
    clearInterval(interval);
    window.location.href = `/checkout?productId=${productId}`;
  }
}, 1000);
