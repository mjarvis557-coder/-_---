import { api } from "./api.js";
import { rupiah, showToast, revealOnScroll } from "./ui.js";

const token = localStorage.getItem("adminToken");
if (!token) {
  window.location.href = "/admin";
}

const statsGrid = document.getElementById("stats-grid");
const productsList = document.getElementById("admin-products");
const ordersList = document.getElementById("orders-list");
const form = document.getElementById("product-form");
const resetButton = document.getElementById("reset-form");
const logoutButton = document.getElementById("logout-button");

revealOnScroll();
loadDashboard();

logoutButton?.addEventListener("click", () => {
  localStorage.removeItem("adminToken");
  window.location.href = "/admin";
});

resetButton?.addEventListener("click", () => form.reset());

form?.addEventListener("submit", async (event) => {
  event.preventDefault();

  try {
    const formData = new FormData(form);
    const id = formData.get("id");
    const method = id ? "PUT" : "POST";
    const url = id ? `/api/admin/products/${id}` : "/api/admin/products";
    await api.upload(url, formData, method, token);
    showToast("Produk berhasil disimpan.", "success");
    form.reset();
    loadDashboard();
  } catch (error) {
    showToast(error.message);
  }
});

async function loadDashboard() {
  try {
    const [{ stats, recentOrders }, { products }, { orders }] = await Promise.all([
      api.get("/api/admin/stats", token),
      api.get("/api/admin/products", token),
      api.get("/api/admin/orders", token)
    ]);

    statsGrid.innerHTML = `
      <article class="glass metric-card"><span class="muted">Total Produk</span><strong>${stats.totalProducts}</strong></article>
      <article class="glass metric-card"><span class="muted">Order Dibayar</span><strong>${stats.totalPaidOrders}</strong></article>
      <article class="glass metric-card"><span class="muted">Total Penjualan</span><strong>${rupiah(stats.totalSales)}</strong></article>
    `;

    productsList.innerHTML = products
      .map(
        (product) => `
          <article class="item-card">
            <strong>${product.name}</strong>
            <p>${product.description}</p>
            <span class="price">${rupiah(product.price)}</span>
            <div class="inline-actions">
              <button class="btn btn-secondary" data-action="edit" data-id="${product.id}">Edit</button>
              <button class="btn btn-secondary" data-action="delete" data-id="${product.id}">Hapus</button>
            </div>
          </article>
        `
      )
      .join("");

    ordersList.innerHTML = (recentOrders.length ? recentOrders : orders)
      .map(
        (order) => `
          <article class="item-card">
            <div class="inline-actions">
              <strong>${order.product_name}</strong>
              <span class="status-pill ${order.status}">${order.status}</span>
            </div>
            <p>${order.email}</p>
            <small class="muted">${order.order_code} • ${rupiah(order.amount)}</small>
            ${order.proof_path ? `<p><a href="/${String(order.proof_path).replaceAll("\\", "/")}" target="_blank">Lihat bukti transfer</a></p>` : ""}
            ${order.status === "waiting_confirmation" ? `<button class="btn btn-primary glow" data-action="approve" data-order="${order.order_code}">Approve Pembayaran</button>` : ""}
          </article>
        `
      )
      .join("");

    bindProductActions(products);
    bindOrderActions();
  } catch (error) {
    showToast(error.message);
    if (error.message.toLowerCase().includes("token")) {
      localStorage.removeItem("adminToken");
      window.location.href = "/admin";
    }
  }
}

function bindOrderActions() {
  ordersList.querySelectorAll("[data-action='approve']").forEach((button) => {
    button.addEventListener("click", async () => {
      try {
        await api.post(`/api/admin/orders/${button.dataset.order}/approve`, {}, token);
        showToast("Pembayaran manual berhasil di-approve.", "success");
        loadDashboard();
      } catch (error) {
        showToast(error.message);
      }
    });
  });
}

function bindProductActions(products) {
  productsList.querySelectorAll("[data-action='edit']").forEach((button) => {
    button.addEventListener("click", () => {
      const product = products.find((item) => item.id === Number(button.dataset.id));
      if (!product) return;
      form.elements.id.value = product.id;
      form.elements.name.value = product.name;
      form.elements.slug.value = product.slug;
      form.elements.description.value = product.description;
      form.elements.price.value = product.price;
      form.elements.deliveryType.value = product.delivery_type;
      form.elements.externalLink.value = product.external_link || "";
      form.elements.zipPassword.value = product.zip_password || "";
      form.elements.isActive.value = product.is_active;
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  });

  productsList.querySelectorAll("[data-action='delete']").forEach((button) => {
    button.addEventListener("click", async () => {
      try {
        await api.delete(`/api/admin/products/${button.dataset.id}`, token);
        showToast("Produk berhasil dihapus.", "success");
        loadDashboard();
      } catch (error) {
        showToast(error.message);
      }
    });
  });
}
